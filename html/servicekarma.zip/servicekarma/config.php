<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'servicekarmadb');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_FRONTEND_URL', '/servicekarma/');
