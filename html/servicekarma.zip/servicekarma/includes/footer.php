<div style="clear:both; height:20px;"></div>
<footer>
	<p>All Rights Reserved Logictree IT Solutions Inc. 2013</p>
</footer>
</body>
</html>