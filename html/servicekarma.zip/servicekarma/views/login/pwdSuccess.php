<?php include HOME . DS . 'includes' . DS . 'header.php'; 
 ?>
<section id="body">
  <div class="container">
    <div class="col12">
    		 <table class="table2 width_full" style="border:solid 1px #0d5478;">
				<tr>
                	<td>
                    	<table align="center">
                        	<tr><td colspan="2" align="center"><h1><?php echo $msg; ?></h1></td></tr>
                         </table>
                    </td>
                </tr>
              </table>  
    </div>
  </div>
</section>
<?php include HOME . DS . 'includes' . DS . 'footer.php'; ?>